var mainDiv = document.getElementById("main-div");

Object.keys(localStorage).forEach(function (key) {
   var heroDetail = JSON.parse(localStorage.getItem(key));
   const item = `<div class="card">
                        <div class="image">
                            <img src="${heroDetail.image.url}">
                        </div>
                        <div class="title">
                            <h1>
                                Name : ${heroDetail.name}
                            </h1>
                        </div>
                        <div class="des">
                            <p>Gender : ${heroDetail.appearance.gender}</p>
                            <p>Height : ${heroDetail.appearance.height[0]}</p>
                            <p>Weight : ${heroDetail.appearance.weight[1]}</p>
                            <p>Eye Color : ${heroDetail.appearance["eye-color"]}</p>
                            <p>Hair Color : ${heroDetail.appearance["hair-color"]}</p>
                            <p>Publisher : ${heroDetail.biography.publisher}</p>
                            <button id = ${heroDetail.id} >Unavorite</button>
                        </div>
                    </div>`;

   const position = "beforeend";
   mainDiv.insertAdjacentHTML(position, item);
});
/*Function will handle click on un-favorite button*/
mainDiv.addEventListener("click", (event) => {
   var heroId = event.target.id;
   event.target.parentNode.parentNode.parentNode.removeChild(
      event.target.parentNode.parentNode
   );
   localStorage.removeItem(heroId);
});
/*Function handel the search btn click*/
document.getElementById("search-btn").addEventListener("click", () => {
   location.replace("./index.html");
});

/* search */

/*Fetching the id so that we will add the event listener to it*/
const searchBox = document.getElementById("search-box");
const searchList = document.getElementById("instant-search__list");
const heroDetails = document.getElementById("hero-details");

/*Adding Event Listener To that search box on keyup event*/
let delay;
searchBox.addEventListener("keyup", (event) => {
   clearTimeout(delay);
   delay = setTimeout(() => {
      const str = searchBox.value;
      while (searchList.firstChild) {
         searchList.removeChild(searchList.firstChild);
      }
      if (str.length >= 1) {
         const xhr = new XMLHttpRequest();
         xhr.open(
            "GET",
            `https://www.superheroapi.com/api.php/3105140062907191/search/${str}`,
            true
         );
         xhr.onload = () => {
            var heroes = JSON.parse(xhr.response);
            var results = heroes.results;
            // if (!searchList.firstChild) {
            for (var result of results) {
               const item = `<li class="instant-search__result" ><span id="${result.id}">${result.name} </span></li>`;
               const position = "beforeend";
               searchList.insertAdjacentHTML(position, item);
            }
            // }
         };
         xhr.send();
      }
   }, 500);
});
/*Function when any search list is clicked*/
searchList.addEventListener("click", (event) => {
   var heroId = event.target.id;
   window.location.href = `./superhero.html?${heroId}`;
});

/*super hero*/

var heroCard = function () {
   const xhr = new XMLHttpRequest();
   var url = document.location.href;
   params = url.split("?")[1];
   xhr.open(
      "GET",
      `https://www.superheroapi.com/api.php/3105140062907191/${params}`,
      true
   );
   xhr.onload = () => {
      var heroDetail = JSON.parse(xhr.response);
      var results = heroDetail.appearance;
      document.getElementById("hero-img").src = `${heroDetail.image.url}`;
      document.getElementById("hero-name").innerHTML = `${heroDetail.name}`;
      document.getElementById(
         "hero-race"
      ).innerHTML = `Race : ${heroDetail.appearance.race}`;
      document.getElementById(
         "hero-gender"
      ).innerHTML = `Gender : ${heroDetail.appearance.gender}`;
      document.getElementById(
         "hero-height"
      ).innerHTML = `Height : ${heroDetail.appearance.height[0]}`;
      document.getElementById(
         "hero-weight"
      ).innerHTML = `Weight : ${heroDetail.appearance.weight[1]}`;
      document.getElementById(
         "eye-color"
      ).innerHTML = `Eye Color : ${heroDetail.appearance["eye-color"]}`;
      document.getElementById(
         "hair-color"
      ).innerHTML = `Hair Color : ${heroDetail.appearance["hair-color"]}`;
      document.getElementById(
         "full-name"
      ).innerHTML = `${heroDetail.biography["full-name"]}`;
      document.getElementById(
         "publisher-name"
      ).innerHTML = `${heroDetail.biography.publisher}`;
      document.getElementById(
         "combat"
      ).innerHTML = `Combat : ${heroDetail.powerstats.combat}`;
      document.getElementById(
         "durability"
      ).innerHTML = `Durability : ${heroDetail.powerstats.durability}`;
      document.getElementById(
         "intelligence"
      ).innerHTML = `Intelligence : ${heroDetail.powerstats.intelligence}`;
      document.getElementById(
         "power"
      ).innerHTML = `Power : ${heroDetail.powerstats.power}`;
      document.getElementById(
         "speed"
      ).innerHTML = `Speed : ${heroDetail.powerstats.speed}`;
      document.getElementById(
         "strength"
      ).innerHTML = `Strength : ${heroDetail.powerstats.strength}`;
      document.getElementById(
         "base"
      ).innerHTML = `BASE : <br>${heroDetail.work.base}.`;
      document.getElementById(
         "occupation"
      ).innerHTML = `Occupation : ${heroDetail.work.occupation}.`;
      /*Adding data to the local storage*/
      var favoriteBtn = document.getElementById("favorite-btn");
      favoriteBtn.addEventListener("click", () => {
         var receiveddata = JSON.stringify(heroDetail);
         // alert("Added To Favorite");
         localStorage.setItem(heroDetail.id, receiveddata);
      });
      /*Removing data from local storage*/
      document
         .getElementById("unfavorite-btn")
         .addEventListener("click", () => {
            // alert("Removed From Favorite");
            localStorage.removeItem(heroDetail.id);
         });
   };
   xhr.send();
};
heroCard();
